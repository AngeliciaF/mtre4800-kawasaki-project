import cv2 as cv
from AImodel import AIModel
import payload
import segment_frame as seg
from time import time as now
from time import sleep
import messaging
import numpy as np
import threading
import multiprocessing
import math
from copy import deepcopy
from math import sqrt
import os
from picamera.array import PiRGBArray
from picamera import PiCamera

from typeServer import sendToTCP as send

model = AIModel()           # Load the evaulation model
my_resolution = (640, 480)  # The desired resolution of the feed
isOn = True                 # The master loop flag
ready = False               # The camera loop flag
payload_type = ""

# Initialize the PiCamera Object and frame
try:
    cam = PiCamera()
    cam.resolution = my_resolution
    cam.framerate = 30
except:
    print("Camera Error")
    isOn = False
raw_capture = PiRGBArray(cam, size = my_resolution)
sleep(0.1) # allow the camera to warm up

while isOn: # Terminating flag
    ready = True
    for frame in cam.capture_continuous(raw_capture, format="bgr", use_video_port=True):
        # global conn
        start = now()
        img = frame.array
        raw_capture.truncate(0)

        if isOn and not payload_type == "":    
            payloads = seg.getPayloads(img)
            seg.sort_by_distance(payloads)

            seg.draw_payloads(img, payloads)
            final = cv.resize(img, my_resolution)
            
            for payload in payloads:
                if payload.type == payload_type:
                    print("Searching for:", payload.type)
                    xMove = payload.x
                    yMove = payload.y
                    rot = payload.r
                    tag_set = {'right_robot_x':xMove, 'right_robot_y':yMove, 'right_robot_r':rot}
                    #print(tag_set)
                    node = messaging.client_send('vision', tag_set, True)
                    # print(str(seg.get_type_by_model(payload, img)))
                    #print('x: ', node['vision_tags']['right_robot_x'])
                    #print('y: ', node['vision_tags']['right_robot_y'])
                    #print('r: ', node['vision_tags']['right_robot_r'])
                    
                    #send(data = tag_set)
                    
                    # Move to and pick up this payload
                    # pickingUpLid = True
                    # while pickingUpLid:
                    #     print("It worked!")
                    #     sleep(5)
                        # Change flag to false when done
                    payload_type = "" # Reset flag


                    cv.imshow("Press 'q' to quit", final)
                    key = cv.waitKey(1) & 0xFF
                    # if the `q` key was pressed, break from the loop
                    if key == ord("q"):
                        break
                    
        else:
            tag_set = {'right_robot_x':0, 'right_robot_y':0, 'right_robot_r':0}
            node = messaging.client_send('robot', tag_set, True)
            payload_type = node['node']['type']
            ready = node['node']['ready']
            print(payload_type, ready)
        
    cam.close()
    cv.destroyAllWindows()
