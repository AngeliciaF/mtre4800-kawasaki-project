import messaging_comms
import socket
from time import time as now
from copy import deepcopy

# Internal
# Intializing tags
class Tags:
    def __init__(self):
        self.vision_tags = { 'x':0 }
        self.robot_tags  = { 'x':0 }
        self.scada_tags  = { 'x':0 }
        self.node = { 'x':0 }
        self.lag = { 'vision':now(), 'robot':now(), 'scada':now(), 'node':now()}
    
    #setting tags
    def tags(self):
        return deepcopy( self.__dict__ )

# tag_server socket
# calling class and functions
def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as tag_server:
        tags = Tags()
        tag_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)    # can reuse socket
        tag_server.bind(('', 8090))     # bind localhot to internal port
        tag_server.listen()             # can talk
        while True:
            connection, _ = tag_server.accept() # listen and talk
            with connection:
                try:
                    message = messaging_comms.recv_msg(connection)  # recieve msgs from messaging 
                    #print("message received")
                except:
                    continue

                if message[0] == 'vision':      # set based on what is recieved
                    tags.vision_tags = message[1]
                    #print("recieved vision tag")
                    #print(message)
                elif message[0] == 'robot':
                    tags.robot_tags = message[1]
                elif message[0] == 'scada':
                    tags.scada_tags = message[1]
                elif message[0] == 'node':
                    tags.node = message[1]

                tags.lag[message[0]] = now()    
                messaging_comms.send_message(tags.tags(), connection)

if __name__ == '__main__':
    main()