import messaging_comms
import socket
import json
from time import time as now
from time import sleep
from copy import deepcopy

#External and comms from server to node red

def sendToTCP(ip = '192.168.0.96', port = 6001, data = 'blah'):
    if ip is None or port is None:
        return
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        s.sendall(json.dumps(data).encode())

        # while 1:
            # tag_set = {'right_robot_x':20, 'right_robot_y':30, 'rot':40}
            # middleman = messaging.client_send('vision', tag_set, True)
            # data = middleman['vision_tags']



def main():
    '''
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect(('192.168.0.96', 6001))
        while 1:
            tag_set = {'right_robot_x':20, 'right_robot_y':30, 'rot':40}
            middleman = messaging.client_send('vision', tag_set, True)
            data = middleman['vision_tags']
            s.sendall(json.dumps(data).encode())
            
        # data = s.recv(1024)
    '''
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:    # socket to node red
        print("Start")
        s.bind(('192.168.0.100', 7000))                             # PC ip and bind to port
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        print("Bind")
        s.listen()
        # conn,addr = s.accept()
        print("Accepted")
        # t = now()
        while True:
            conn, _ = s.accept()
            with conn:
                recData = conn.recv(4096)       # send to port that will be recievving from node red
                #print("Recieved")
                recData = json.loads(recData.decode())  # decodes data; recieved in json
                #print("Decoded")
                #print("Tag Set")

                # Has to be json format (dict); 
                # always send data * 
                # it will be over written 
                # dummy
                middleman = messaging_comms.client_send('node', recData, True) 

                # call from vision tags

                #data = middleman['vision_tags']
                #data = b'data'
                #print("Client Send")
                #print(str(data))

                # send all that messaging client has stored
                # encode bytes to go to node red
                conn.sendall(json.dumps(middleman).encode('utf-8'))
                # distance = middleman['node']['type']
                #print("Client Recieve:")
                # print(distance)
                #tagly = {'right_robot_x':20, 'right_robot_y':30, 'rot':40}
                #yeet = messaging.client_send('node', tagly, True)
                #yeezy = yeet['node']
                #strYeezy = str(yeezy)
                #yeezyEncode = strYeezy.encode()
                #conn.send(yeezyEncode)
                # ----
                # Convert this dictionary into a serialized JSON object somehow and then it should work
                #conn.sendall(json.dumps(middleman['vision_tags']['right_robot_x']).encode())
                #sleep(1)
                #messaging.send_message(data, conn)
               
                #conn.sendall(json.dumps(middleman['vision_tags']).encode())
                # data.encode()
                # s.sendall(data)
                # ----
                #s.close()
                # if not data:
                    # break

if __name__ == '__main__':
    main()