from copy import deepcopy
import messaging_kinect
from payload_kinect import Payload
import cv2
from time import sleep


# def type_to_offset(type):
#     case = {
#         0:3,
#         1:4,
#         2:7
#     }
#     return case.get(type)

# print(type_to_offset(0))
payloads = []
i = 0
while True:
    sleep(1)
    test_payload = Payload()
    payloads.append(test_payload)
    selected = 0
    tag_set = Payload().tags()
    i +=1
    # payloads[selected].left_robot_x = i
    # payloads[selected].left_robot_y = i
    # payloads[selected].left_robot_r = i
    # payloads[selected].left_robot_z = i
    # payloads[selected].type = i
    # payloads[selected].left_robot_x_init = 23
    # payloads[selected].left_robot_y_init = 42

    tag_set = deepcopy(payloads[selected].tags())

    tag_set = {'left_robot_x':8, 'left_robot_y':2, 'left_robot_z':3, 'left_robot_r':4, \
               'type': 0, 'left_robot_x_init':6, 'left_robot_y_init':7}
    print(tag_set)
    response = messaging_kinect.node_red(tag_set)
    print(type(response))
    print("Response:", response)
    #node = messaging_kinect.client_send('vision', tag_set, True)
    #print(node)
    # print(scada['vision_tags'])