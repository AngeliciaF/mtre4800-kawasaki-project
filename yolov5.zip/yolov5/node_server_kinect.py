import messaging_kinect
import socket
import json
from time import time as now
from time import sleep
from copy import deepcopy

#External and comms from server to node red
def sendToTCP(ip = '192.168.0.96', port = 7000, data = 'blah'): # R_bot = port: 6001
    if ip is None or port is None:
        return
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        s.sendall(json.dumps(data).encode())
'''
        # while 1:
            # tag_set = {'right_robot_x':20, 'right_robot_y':30, 'rot':40}
            # middleman = messaging.client_send('vision', tag_set, True)
            # data = middleman['vision_tags']
'''

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:    # socket to node red
        print("Start")
        s.bind(('192.168.0.100', 7001))   # R_bot = port: 6007;   PC ip and bind to same port in Node-RED
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        print("Bind")
        s.listen()
        print("Listen")
        # conn,addr = s.accept()
        # t = now()
        while True:
            conn, _ = s.accept()
            print("Accepted: External Server 2 Node-RED")
            with conn:
                print("Connected")
                recData = conn.recv(4097)       # send to port that will be recievving from node red
                recData = json.loads(recData.decode())  # decodes data; recieved in json
                print(recData)
                '''
                # Has to be json format (dict); 
                # always send data * 
                # it will be over written 
                # dummy
                '''
                middle_woman = messaging_kinect.client_send('node', recData, True) 
                '''
                # call from vision tags

                # send all that messaging client has stored
                # encode bytes to go to node red
                '''
                conn.sendall(json.dumps(middle_woman).encode('utf-8'))
                '''
                #tagly = {'right_robot_x':20, 'right_robot_y':30, 'rot':40}
                #yeet = messaging.client_send('node', tagly, True)
                #yeezy = yeet['node']
                #strYeezy = str(yeezy)
                #yeezyEncode = strYeezy.encode()
                #conn.send(yeezyEncode)
                # ----
                # Convert this dictionary into a serialized JSON object somehow and then it should work
                #conn.sendall(json.dumps(middleman['vision_tags']['right_robot_x']).encode())
                '''

if __name__ == '__main__':
    main()