import math
import time
from time import time as now
import cv2
from cv2 import imshow
import numpy as numpy
import numpy as np
from payload_kinect import Payload

# Get payloads and return payloads
def get_orientation(payload, image):
    # Set workspace boundaries (Camera FoV) and resize the image
    x_crop, y_crop = 20, 90

    image = cv2.resize(image[x_crop:560,y_crop:560],(640,480))
    
    # Grayscale image
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Dilate image (Add white pixels to mask based on k_size)
    k_size = 1
    kernelmatrix = np.ones((k_size, k_size), np.uint8)
    dilated = cv2.dilate(gray, kernelmatrix)

    # Blur image
    blurry = cv2.GaussianBlur(dilated,(9,9), 2)

    # Mask image
    # payload_type = 0
    # if payload_type == 0: # Black Box
    if payload.type == 0: # Black Box
        lower_mask = 80 #110 40  100 100
        upper_mask = 180 #215 130 170 155
    # elif payload_type == 1: # Orange Bucket
    elif payload.type == 1: # Orange Bucket
        lower_mask = 60 #200 110 40  100 100
        upper_mask = 210 #250 215 130 170 155
    # elif payload_type == 2: # White Box
    elif payload.type == 2: # White Box
        lower_mask = 80 #60 110 40  100 100
        upper_mask = 180 #210 215 130 170 155
    mask = cv2.inRange(blurry, lower_mask, upper_mask)

    # Invert masked image
    lower_invert, upper_invert = 0, 255
    _, inv_image = cv2.threshold(mask, lower_invert, upper_invert, cv2.THRESH_BINARY_INV)

    # cv2.imshow('Mask/Inv', np.vstack([mask,inv_image]))
    # cv2.waitKey(2000)

    # Find the contours in the image
    contours, _ = cv2.findContours(inv_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    print("Number of Contours found = " + str(len(contours)))

    # copy = image.copy()
    # contours_image = cv2.drawContours(copy, contours, -1, (255,0,255), 2)
    refined_contours = []
    contour_area_list = []

    # Check area of contours to refine payload detection
    # min_contour_area, max_contour_area = 4500, 26000  # At home
    min_contour_area, max_contour_area = 25000, 78000   # At measure
    count = 0
    for index, c in enumerate(contours):
        contour_area = cv2.contourArea(c, False)
        count += 20
        print(contour_area)
        if abs(contour_area >= min_contour_area) and abs(contour_area) <= max_contour_area:
            refined_contours.append(c)
            contour_area_list.append(contour_area)
            # cv2.putText(image, f'{int(contour_area)}',(int(image.shape[1]/2) - 230, int(image.shape[0]/2) + count), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            # cv2.imshow("min/max", image)
            # cv2.waitKey(0)

    print("Number of Refined Contours found = " + str(len(refined_contours)))

    center = (0,0)
    selected = -1
    payloads = []
    orientation_bbox = []
    regular_bbox_list = []
    index = 0
    for contour in refined_contours:
        # Orientation bbox
        # Contours -> Rotated rectangular boundaries
        bounds = cv2.minAreaRect(contour)
        # Rotated rectangular boundaries -> Oriented Bbox
        oriented_bbox = cv2.boxPoints(bounds)
        # Box corners -> int
        oriented_bbox = numpy.int0(oriented_bbox)
        orientation_bbox.append(oriented_bbox)
        # cv2.drawContours(image, [oriented_bbox], 0, (0, 255, 255), 2)
        # cv2.imshow("Contours", image)
        # cv2.waitKey(0)
        # Regular bbox

        # Center_x, center_y, width, height from boundingRect()
        x, y, w, h = cv2.boundingRect(contour)
        regular_bbox = (x, y, w, h)
        regular_bbox_list.append(regular_bbox)

        # Calculate the closest orientated bbox
        # Subtract old center x from width/2
        oc_dx = abs(center[0]-(image.shape[1]/2))
        # Subtract old center y height/2
        oc_dy = abs(center[1]-(image.shape[0]/2))
        # Calculate old distance
        old_distance = math.sqrt(oc_dx**2+oc_dy**2)

        # Center of orientated bbox
        new_center = numpy.int0(bounds[0])
        # Subtract new center x from width/2
        nc_dx = abs(new_center[0]-(image.shape[1]/2))
        # Subtract new center y height/2
        nc_dy = abs(new_center[1]-(image.shape[0]/2))
        # Calculate new distance
        new_distance = math.sqrt(nc_dx**2+nc_dy**2)

        # Add new payload to payload list
        new_payload = Payload()
        new_payload.bounds = bounds
        # new_payload.boxes = regular_bbox
        
        # Pixel to mm ratio (pixels/mm)
        new_payload.left_robot_x = int((new_center[0])+y_crop)   # Right y boundary
        new_payload.left_robot_y = int((new_center[1])+x_crop)   # Left x boundary
        
        new_payload.left_robot_r = bounds[2] + 1
        new_payload.distance = int(new_distance)         # Distance from center (Avg of x and y ratios)
        payloads.append(new_payload)

        # Compare payload distances and select closest
        if new_distance < old_distance:
            closest_index = index
            center = new_center
        index += 1  

        # payloads.append(new_payload)

        # payloads[closest_index].left_robot_x = int((new_center[0])+y_crop)   # Right y boundary
        # payloads[closest_index].left_robot_y = int((new_center[1])+x_crop)   # Left x boundary
        # payloads[closest_index].left_robot_r = bounds[2]
        # payloads[closest_index].distance = int(new_distance)         # Distance from center (Avg of x and y ratios)

    # payload.left_robot_x = int((new_center[0])+y_crop)   # Right y boundary
    # payload.left_robot_y = int((new_center[1])+x_crop)   # Left x boundary
    # payload.left_robot_r = payloads[closest_index].bounds[2]
    # payload.distance = int(new_distance)         # Distance from center (Avg of x and y ratios)
        

        payload.left_robot_x = int((center[0])+y_crop)   # Right y boundary
        payload.left_robot_y = int((center[1])+x_crop)   # Left x boundary
        payload.left_robot_r = payloads[closest_index].bounds[2]
        payload.distance = int(new_distance)         # Distance from center (Avg of x and y ratios)
        
    # cv2.drawContours(image, [payloads[closest_index].boxes], 0, (0, 255, 255), 2)
    # cv2.imshow("Contours", image)
    # cv2.waitKey(0)        

    if len(payloads) > 0:
        payloads[closest_index].selected = 1
        # return payloads[closest_index], image
        return payloads[closest_index]
    # return payloads, orientation_bbox, regular_bbox_list
    print()
    return None

# FIXME: Work on this (Get bounding boxes then Draw the payloads on the image)
# Add getPayload and draw payloads to the test code at the bottom
# Returns bounding boxes and image sample

def adjust_angle(payload):
    if payload.bounds != None:
        width = payload.bounds[1][0]
        length = payload.bounds[1][1]
        # If the angle is close to 0 or 90
        if abs(payload.left_robot_r - 90) <= 1 or abs(payload.left_robot_r) < 1:
            return 0
        # If the payload is circular (no rotation needed)
        if payload.type == 1:
            return 0
        # If the lower right side is short
        elif width < length:
            return -1 * payload.left_robot_r
        # If the lower right side is long
        else: # payload.bounds[1][0] < payload.bounds[1][1]
            return 90 - payload.left_robot_r
    else:
        print("No bounds.")
        return payload.left_robot_r

# Place caps to measure in mm
# take a picture
# measure in pixel
# MS Paint or OpenCV
# Robot at home
# Robot at 4 ft off the ground
def convert_units(payload, image_shape, response):
    if response["33_right_ready"]:  #ratio/bigger = smaller mm on image
        # x_ratio, y_ratio, c_ratio = 4.068/1.3, 4.966/1.86, 4.517  # Home ratios
        # teach pendant mm is moving more than image
        # ratio/lower = bigger image ratio

        # if tp is moving more than image, decrease denom
        x_ratio, y_ratio, c_ratio = 3.129/0.79, 2.670/.8, 2.900  # Home ratios
        x_value = payload.left_robot_x_init
        y_value = payload.left_robot_y_init
        y_offset = -15
        x_offset = -20
    else:
        # x_ratio, y_ratio, c_ratio = 2.306, 2.435, 2.371   # 4 ft ratios
        # x_ratio, y_ratio, c_ratio = 2.306/1.3, 2.435/1.86, 2.371   # 4 ft ratios
        x_ratio, y_ratio, c_ratio = 1.774, 1.309, 1.541   # 4 ft ratios
        x_value = payload.left_robot_x
        y_value = payload.left_robot_y
        y_offset = -75
        x_offset = 10

    # TODO: Re-measure center
    y = (x_value - (image_shape[1]/2) + y_offset)
    x = (y_value - (image_shape[0]/2) + x_offset)
    
    x *= x_ratio
    y *= y_ratio
    r = adjust_angle(payload) #/1.02
    payload.left_robot_x = int(x)
    payload.left_robot_y = int(y)
    payload.left_robot_x_init = int(x)
    payload.left_robot_y_init = int(y)
    payload.left_robot_r = int(r)
    return int(x), int(y), int(r)

# FIXME: Ask Tim: Can you please explain this?
# Limited by sensor cable
# Uses long side to pick refernce origin
# Adjust for bucket
# -bounds to make sure the axis line up
# cv cw -> +
# robot ccw -> +
# def reference_rotation(bounds, payload):
#     adjust = 0
#     if payload != 1:
#         width = bounds[1][0]
#         height = bounds[1][1]
#         if width < height:
#             return (90 - bounds[2]) + adjust
#         else:
#             return (-bounds[2]) + adjust
#     else:
#         return adjust

# def draw_payloads(image, payloads, bounding_box, labels):
def draw_payloads(final_image, payload, response):
    # final_image = cv2.cvtColor(final_image, cv2.COLOR_BGR2RGB)
    position = "Home Position"

    # for index, payload in enumerate(payloads):
        # if payload.selected:
    print("draw payloads.selected:", payload.selected)
    center = (payload.left_robot_x, payload.left_robot_y)
    color = (0,0,255)

    # Set drawing variables
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.5
    thickness = 2

    if payload.type == 0:
        color = (255, 0, 0) # BGR
        label = "Black Box"
        print(f"Black, plastic box was found! {payload.distance}\n")
    elif payload.type == 1:
        color = (0, 255, 0)
        label = "Orange Bucket"
        print(f"Orange, plastic bucket was found! {payload.distance}\n")
    elif payload.type == 2:
        color = (255, 255, 0)
        label = "White Box"
        print(f"White, Styrofoam box was found! {payload.distance}\n")
    else:
        print("No containers!\n")
    
    if not response["35_payload_grasped"]:
        # Payload grasped stuff on image
        # cv2.putText(final_image, f"The {label} has been grasped.", (10, final_image.shape[0]- 10), font, font_scale, (0, 255, 255), thickness)
        # final_image = cv2.cvtColor(final_image, cv2.COLOR_BGR2RGB)
        cv2.putText(final_image, f"The payload has been grasped.", (10, final_image.shape[0]- 10), font, font_scale, (0, 255, 255), thickness)
        return final_image
    
    elif response["36_position_measured"]:
        # final_image = cv2.cvtColor(final_image, cv2.COLOR_BGR2RGB)

        # Draw Orientation
        # Display Height
        # Puttext measure position

        # Draw orientation stuff on image
        position = "Measuring/Orientation Position"

        cv2.putText(final_image, position, (10, final_image.shape[0]- 10), font, font_scale, (0, 255, 255), thickness)
        # cv2.drawContours(final_image, payload.boxes, 0, (255, 255, 0), 2)

        # Dimensions/ Orientation
        cv2.putText(final_image, "X: " + str(round(payload.left_robot_x, 0)) + 'mm', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        cv2.putText(final_image, "Y: " + str(round(payload.left_robot_y, 0)) + 'mm', (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        cv2.putText(final_image, "Z: " + str(round(payload.left_robot_z, 0)) + 'mm', (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        cv2.putText(final_image, "R: " + str(round(payload.left_robot_r, 0)) + ' degrees', (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        # cv2.putText(final_image, "H: " + str(round(payload.height, 0)) + 'mm', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        print("z:", payload.left_robot_x)

    elif response["33_right_ready"]:
        # final_image = cv2.cvtColor(final_image, cv2.COLOR_BGR2RGB)

        # Draw ML boxes with predictions
        # Puttext home position
        cv2.putText(final_image, position, (10, final_image.shape[0]- 10), font, font_scale, (0, 255, 255), thickness)

        # Draw ML stuff on image
        cv2.circle(final_image, center, 3, color, -1)
        cv2.rectangle(final_image, (payload.boxes[0], payload.boxes[2]), (payload.boxes[1], payload.boxes[3]), color, 2)
        # cv2.putText(image, "{}: {} [{:.2f}]".format(payload.type, label, float(payload.confidence)), (payload.boxes[0], payload.boxes[2]-5), font, font_scale, color, thickness)
        cv2.putText(final_image, "{}: {} [{}]".format(payload.type, label, payload.confidence), (payload.boxes[0], payload.boxes[2]-5), font, font_scale, color, thickness)
        # cv2.putText(final_image, str(round(center[0], 2)), (center[0],  center[1] - 20), font, font_scale, color, thickness)
        # cv2.putText(final_image, str(round(center[1], 2)), (center[0] , center[1]), font, font_scale, color, thickness)
        # cv2.putText(final_image, str(round(payload.distance, 2)), (center[0], center[1] + 20), font, font_scale, color, thickness)
        # cv2.line(final_image, (int(final_image.shape[1]/2), int(final_image.shape[0]/2)), center, color, thickness-1)

        # if payload.bounds is not None:
        # cv2.drawContours(img, [bounding_box], 0, color, 2)
        oriented_bbox = cv2.boxPoints(payload.bounds)
        # Box corners -> int
        oriented_bbox = numpy.int0(oriented_bbox)
        # cv2.drawContours(final_image, [oriented_bbox], 0, (255, 255, 0), 2)
        print("center:", center)


        # Dimensions/ Orientation
        cv2.putText(final_image, "X init: " + str(round(payload.left_robot_x_init, 0)) + 'mm', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        cv2.putText(final_image, "Y init: " + str(round(payload.left_robot_y_init, 0)) + 'mm', (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        # cv2.putText(final_image, "Z: " + str(round(payload.left_robot_z, 0)) + 'mm', (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        # cv2.putText(final_image, "R: " + str(round(payload.left_robot_r, 0)) + ' degrees', (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        # cv2.putText(final_image, "D: " + str(round(payload.distance, 0)) + 'mm', (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        # cv2.putText(final_image, "H: " + str(round(payload.height, 0)) + 'mm', (10, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        cv2.putText(final_image, "Type: " + str(round(payload.type, 0)), (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        # cv2.line(image, (int(image.shape[1]/2),int(image.shape[0]/2)), center, color, 1)

    else:
        final_image = cv2.cvtColor(final_image, cv2.COLOR_BGR2RGB)
        cv2.putText(final_image, "Returning to Home position", (int(final_image.shape[1]/2) - 230, int(final_image.shape[0]/2)), font, font_scale, (255,0,0), thickness)

    return final_image
