# This didn't work because I was unable to download onnx.
 
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.autograd import Variable
import onnx
# from onnx_tf.backend import prepare
from collections import OrderedDict
import tensorflow as tf
 
 
'''
This file can be used to convert a pytorch model to a tensorflow lite model.
This conversion should be done on a pc, the code here is given as a reference.
'''
 
class NeuralNetwork(nn.Module):
    ndes = 1000
    def __init__(self):
        super(NeuralNetwork,self).__init__()
        shape = 40
        self.fc1 = nn.Linear(shape*shape, self.ndes)
        self.s1  = nn.Sigmoid()
        self.fc2 = nn.Linear(self.ndes, self.ndes)
        self.s2  = nn.Sigmoid()
        self.fc3 = nn.Linear(self.ndes, 4)
 
    def forward(self, x):
        x = x.view(x.size(0), -1)
        out = self.fc1(x)
        out = self.s1(out)
        out = self.fc2(out)
        out = self.s2(out)
        out = self.fc3(out)
        return (out)
 
image_size = 40
 
# load trained pytorch model
trained_model = NeuralNetwork().to('cpu')
model = torch.hub.load('ultralytics/yolov5', 'custom', path='mtre4800-kawasaki-project/best.pt')  # local model
model.cpu()
 
# trained_model.load_state_dict(torch.load('pytorch_model.pth', map_location=torch.device('cpu')))
# save as onnx model
dummy_input = Variable(torch.randn(1, 1, image_size, image_size))
torch.onnx.export(model, dummy_input, "onnx_model.onnx")
#  Load the onnx model
model = onnx.load('onnx_model.onnx')
# Import the ONNX model to Tensorflow
tf_rep = prepare(model)
# save the model as tensorflow model
tf_rep.export_graph('tensorflow_model.pb')
# load the tensorflow model
converter = tf.lite.TFLiteConverter.from_saved_model("tensorflow_model.pb")
# convert model to tensorflow lite
tflite_model = converter.convert()
# save the model as a tensorflow lite model
open("model_1.tflite", "wb").write(tflite_model)
 
 
 
# saved_model_dir = 'mtre4800-kawasaki-project/best.pt'
 
# # Convert the model
# converter = tf.lite.TFLiteConverter.from_saved_model(saved_model_dir) # path to the SavedModel directory
# tflite_model = converter.convert()
 
# # Save the model.
# with open('model.tflite', 'wb') as f:
#   f.write(tflite_model)
