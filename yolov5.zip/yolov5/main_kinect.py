import cv2
# from AImodel import AIModel
from Yolov5Model import Yolov5Model
# import cameraInterface
from payload_kinect import Payload
import segmentation2_kinect as segmentation
# from segmentation2_kinect import (getPayload, getPayloads)
from time import time as now
from time import sleep
import messaging_kinect
import numpy as np
import videoServer_kinect as flask
import threading
import multiprocessing
import math
from copy import copy, deepcopy
from math import sqrt

import torch
import torch.nn as nn
import freenect
import kinect_utils
import os

# os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' #Fix for tensorflow version error
# Start the video server
###threading.Thread(target=lambda: flask.main()).start()

# Load ML model to call get_prediction
yolo_model = Yolov5Model()

# TODO: Use the select_device()
# device = torch.device('cpu')
# device = torch.device('cuda:0')

# Load the ML model
# model = torch.hub.load('ultralytics/yolov5', 'custom', path='mtre4800-kawasaki-project/best.pt')  # local model
# model = DetectMultiBackend(weights, device=device)

# TODO: Set the heights from the Kinect distance program here
# Order of heights are based on the training/labelling order
# From 24 in. from the ground (tallest container can be 24 in. in the future with this method)
# heights = [-254, -374, -343, -275, 0]
# heights = [-254, -275, bucket, 0]

# scada = {'robot_tags':{'home':True}}
response = {"33_right_ready" : True, "35_payload_grasped" : False, "36_position_measured" : False}

kinect_utils.initialize_kinect()

### Initialize Camera here
### initialize_kinect()

frame, _ = freenect.sync_get_video()

# frame = True
frame_count = 0
# for frame in range(0, 100):
while frame is not None:
    print("frame is True")
    # Get the RGB image from the Kinect
    rgb_image = kinect_utils.get_video()
    depth_array = kinect_utils.get_depth()

    print("Got Frames from kinect")

    sleep(.03)
    # sleep(1)

    # rgb_image = cv2.imread('mtre4800-kawasaki-project/three_containers4.jpg') #TEST IMAGE
    rgb_image = cv2.resize(rgb_image, (640, 480))
    print("Resized the image")

    # cv2.rotate(rgb_image,cv2.ROTATE_180)

    # Change test frame from RGB to BGR
    # rgb_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)

    # Make a copy of the original image to be drawn on
    final_image = rgb_image.copy()    

    # Set start time
    start = now()

    # Get payloads and both types of bounding boxes
    # try:
    payloads, payload_type, payload_boxes, payload_confidence, rgb_image, final_image = yolo_model.get_prediction(yolo_model.model, rgb_image, final_image)

    print("Number of payloads:", len(payloads))
    # except:
    #     print("prediction error")
    # print(regular_bbox)

    # home, meas = 1,0 #TEST CONDITIONS
    # bounding_box = None
    x,y,z,height = 0,0,0,0

    if len(payloads) == 0:
        try:
            tag_set = Payload().tags()
            tag_set = deepcopy(payload.tags())
            tag_set['number_of_payloads'] = len(payloads)
            print("Tags:",tag_set)
            response = messaging_kinect.node_red(tag_set)
            print("Response:", response)
            print("done sending to client")
            print("response[33_right_ready]", response["33_right_ready"])
            print("response[35_payload_grasped] not", response["35_payload_grasped"])
            print("response[36_position_measured]", response["36_position_measured"])

        except:
            print("Couldn't send data1")
            continue

    for index, payload in enumerate(payloads):
        print("pl selected?",payload.selected,"pl type",payload.type,"pl boxes",payload.boxes,"for start",now())
        if payload.selected:
            # payload.type = payload_type
            # payload.confidence = payload_confidence
            selected = index
            if response is None or len(response) == 0 or not bool(response): # or response is empty
                print("ITS NONE")
            elif response["33_right_ready"]:
                print("Home Position")
                # payload.left_robot_x = payload.left_robot_x_init
                # payload.left_robot_y = payload.left_robot_y_init
                # payload.left_robot_x_init
                # payload.left_robot_y_init
                x, y, _ = segmentation.convert_units(payload, rgb_image.shape, response) # Convert x and y from pixel to mm distances

                payload.left_robot_x = x
                payload.left_robot_y = y
                payload.left_robot_x_init = x
                payload.left_robot_y_init = y
                final_image = segmentation.draw_payloads(final_image, payload, response)
                # tag_set['left_robot_x'] = payload.left_robot_x_init
                # tag_set['left_robot_y'] = payload.left_robot_y_init
            # We all ready have the bbox
            # bounding_box, sample = segmentation.getPayload(payload, rgb_image)

                # Get the closest prediction
                # predicted_labels, closest_prediction, image = yolo_model.getPrediction(yolo_model.model, sample, payload)
                # rgb_image = yolo_model.getPrediction(yolo_model.model, payload, rgb_image)
                # print("Home")
                # payload.type = closest_prediction
                # payload.z = heights[payload.type]
                ###x, y, r, distance = segmentation.convert_units(payload, rgb_image.shape, home = True) # Convert x and y from pixel to mm distances
            
            #REAL If the robot is at the measurement position, take a height estimate and get orientation
            elif response["36_position_measured"]:
                # payloads, orientation_bbox, regular_bbox = segmentation.get_orientation(rgb_image)
                payload = segmentation.get_orientation(payload, rgb_image)

                if len(payloads) > 0 and payload != None:
                    final_image = segmentation.draw_payloads(final_image, payload, response)
                    payload.type = payload_type
                    payload.boxes = payload_boxes
                    payload.confidence = payload_confidence
                    # payload.left_robot_x_init, payload.left_robot_y_init, _ = segmentation.convert_units(payloads[selected], rgb_image.shape, init = True)
                    z, height = kinect_utils.get_dist(depth_array, payload,payload_type, payload_boxes)
                    # payload.left_robot_z, payload.height = -830, 300
                    x, y, r = segmentation.convert_units(payload, rgb_image.shape, response) # Convert x and y from pixel to mm distances
                    # payload.type = payload_type
                    # Setting the tags of the closest payload
                    # final_image = segmentation.draw_payloads(rgb_image, payload)
                    # tag_set = Payload().tags()
                    # tag_set = deepcopy(payloads[selected].tags())
                    # tag_set = deepcopy(payload.tags())
                    # tag_set['number_of_payloads'] = len(payloads)
                    # print("Tags:",tag_set)
                    # # response = messaging_kinect.node_red(tag_set)
                    # response = messaging_kinect.node_red(tag_set)
                    # print("Response:", response)
                    # print("done sending to client")

                else:
                    try:
                        cv2.putText(rgb_image, "No containers were detected.", (int(rgb_image.shape[1]/2) - 230, int(rgb_image.shape[0]/2)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0), 2)
                    except:
                        print("No Containers message error")
                        sleep(1)
                        # break # May skip senting info to NR

            elif not response["35_payload_grasped"]:
                print("Payload grasped")
                
                final_image = segmentation.draw_payloads(final_image, payload, response)
            else:
                print("Do nothing")
            
            ###tag_set = Payload().tags()
            # tag_set = deepcopy(payloads[selected].tags())
            # if payload is not None:
            #     tag_set = deepcopy(payload.tags())
            #     tag_set['number_of_payloads'] = len(payloads)
            # print("Tags:",tag_set)
            # response = messaging_kinect.node_red(tag_set)
            if payload is not None:
                try:
                    tag_set = Payload().tags()
                    tag_set = deepcopy(payload.tags())
                    tag_set['number_of_payloads'] = len(payloads)
                    print("Tags:",tag_set)
                    response = messaging_kinect.node_red(tag_set)
                    # TODO: Remove when server is back up
                    # response = {"33_right_ready" : True, "35_payload_grasped" : True, "36_position_measured" : False}

                    print("Response:", response)
                    print("done sending to client")
                    print("response[33_right_ready]", response["33_right_ready"])
                    print("response[35_payload_grasped] not", response["35_payload_grasped"])
                    print("response[36_position_measured]", response["36_position_measured"])

                except:
                    print("Couldn't send data2")
                    continue

            break



    # Push image to video server
    final_image = cv2.resize(final_image,(648,488))
    final_image = cv2.cvtColor(final_image, cv2.COLOR_BGR2RGB)
    # flask.push(rgb_image)
    cv2.imshow("Final", final_image)
    kinect_utils.show_depth(depth_array)

    cv2.waitKey(1)
    #if (cv2.waitKey(1) & 0xFF) == 27:
    #    break

    frame_count += 1
    print("Frame count:", frame_count)

print("exited while loop")