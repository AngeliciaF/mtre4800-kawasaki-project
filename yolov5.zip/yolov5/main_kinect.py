import cv2
# from AImodel import AIModel
from Yolov5Model import Yolov5Model
# import cameraInterface
from payload_kinect import Payload
import segmentation2_kinect as segmentation
# from segmentation2_kinect import (getPayload, getPayloads)
from time import time as now
from time import sleep
import messaging_kinect
import numpy as np
import videoServer_kinect as flask
import threading
import multiprocessing
import math
from copy import copy, deepcopy
from math import sqrt

import torch
import torch.nn as nn
import freenect
import kinect_utils
import os

# os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' #Fix for tensorflow version error
# Start the video server
###threading.Thread(target=lambda: flask.main()).start()

# Load ML model to call get_prediction
yolo_model = Yolov5Model()

# TODO: Use the select_device()
# device = torch.device('cpu')
# device = torch.device('cuda:0')

# Load the ML model
# model = torch.hub.load('ultralytics/yolov5', 'custom', path='mtre4800-kawasaki-project/best.pt')  # local model
# model = DetectMultiBackend(weights, device=device)

# Set signals for the Python Code
response = {"33_right_ready" : True, "35_payload_grasped" : False, "36_position_measured" : False}

kinect_utils.initialize_kinect()

# Name the video feed window
video_feed_name = "RGB Video Feed"
cv2.namedWindow(video_feed_name, cv2.WINDOW_NORMAL)

depth_feed_name = "ML Video Feed"
cv2.namedWindow(video_feed_name, cv2.WINDOW_NORMAL)

frame, _ = freenect.sync_get_video()

# frame = True
frame_count = 0
# for frame in range(0, 100):
while frame is not None:
    print("frame is True")
    # Get the RGB image from the Kinect
    rgb_image = kinect_utils.get_video()
    depth_array = kinect_utils.get_depth()

    # print("Got Frames from kinect")frfffff

    # sleep(.05)
    # sleep(1)

    # rgb_image = cv2.imread('mtre4800-kawasaki-project/three_containers4.jpg') #TEST IMAGE
    rgb_image = cv2.resize(rgb_image, (640, 480))
    # print("Resized the image")

    # cv2.rotate(rgb_image,cv2.ROTATE_180)

    # Change test frame from RGB to BGR
    # rgb_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)

    # Make a copy of the original image to be drawn on
    final_image = rgb_image.copy()    

    # Set start time
    start = now()

    # Get payloads and both types of bounding boxes
    payloads, payload_type, payload_boxes, payload_confidence, rgb_image, final_image = yolo_model.get_prediction(yolo_model.model, rgb_image, final_image)

    print("Number of payloads:", len(payloads))

    x,y,z,height = 0,0,0,0
    f = ""
    if len(payloads) == 0:
        try:
            # final_image = segmentation.draw_payloads(final_image, response, None)
            final_image = segmentation.draw_payloads(final_image, response)
            print("1")
            f = "132"
            tag_set = Payload().tags()
            # tag_set = deepcopy(payload.tags())
            print("2")
            tag_set['number_of_payloads'] = len(payloads)
            print("3")
            print("Tags:",tag_set)
            print("4")
            response = messaging_kinect.node_red(tag_set)
            print("5")
            print("Response No payloads:", response)
            print("done sending to client")
            print("response[33_right_ready]", response["33_right_ready"])
            print("response[35_payload_grasped] not", response["35_payload_grasped"])
            print("response[36_position_measured]", response["36_position_measured"])
        except:
            print("Couldn't send data1")
            try:
                tag_set = Payload().tags()
                tag_set['number_of_payloads'] = len(payloads)
                print("Tags:",tag_set)
                response = messaging_kinect.node_red(tag_set)
            except:
                print("Couldn't send data2")
                continue

    for index, payload in enumerate(payloads):
        print("pl selected?",payload.selected,"pl type",payload.type,"pl boxes",payload.boxes,"for start",now())
        if payload.selected:
            # payload.type = payload_type
            # payload.confidence = payload_confidence
            selected = index
            if response is None or len(response) == 0 or not bool(response): # or response is empty
                print("ITS NONE")
            elif response["33_right_ready"]:
                print("Home Position")
                # payload.left_robot_x = payload.left_robot_x_init
                # payload.left_robot_y = payload.left_robot_y_init
                # payload.left_robot_x_init
                # payload.left_robot_y_init
                x, y, _ = segmentation.convert_units(payload, rgb_image.shape, response) # Convert x and y from pixel to mm distances
                payload.left_robot_x = x
                payload.left_robot_y = y
                payload.left_robot_x_init = x
                payload.left_robot_y_init = y
                # tag_set['left_robot_x'] = payload.left_robot_x_init
                # tag_set['left_robot_y'] = payload.left_robot_y_init
  
            #REAL If the robot is at the measurement position, take a height estimate and get orientation
            elif response["36_position_measured"]:
                # payloads, orientation_bbox, regular_bbox = segmentation.get_orientation(rgb_image)
                payload, final_image = segmentation.get_orientation(payload, rgb_image)

                if len(payloads) > 0 and payload != None:
                    payload.type = payload_type
                    payload.boxes = payload_boxes
                    payload.confidence = payload_confidence

                    z, height = kinect_utils.get_dist(payload)
                    payload.left_robot_z, payload.height = z, height

                    x, y, r = segmentation.convert_units(payload, rgb_image.shape, response) # Convert x and y from pixel to mm distances
                    if payload.type  == 0:
                        payload.left_robot_x = x # + 60
                        payload.left_robot_y = y # + 70
                    else:
                        payload.left_robot_x = x
                        payload.left_robot_y = y
                else:
                    try:
                        cv2.putText(final_image, "Placing container on the conveyor belt.", (10, final_image.shape[0]- 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
                    except:
                        print("No Containers message error")
                        sleep(1)
                        # break # May skip senting info to NR

            elif not response["35_payload_grasped"]:
                print("Payload grasped")
            else:
                x, y, _ = segmentation.convert_units(payload, rgb_image.shape, response) # Convert x and y from pixel to mm distances
                payload.left_robot_x = x
                payload.left_robot_y = y

                print("Do nothing")
            
            #TODO: This probably doesn't need to be checked at this point.
            if payload is not None:
                try:
                    final_image = segmentation.draw_payloads(final_image, response, payload)
                    tag_set = Payload().tags()
                    tag_set = deepcopy(payload.tags())
                    tag_set['number_of_payloads'] = len(payloads)

                    # if not response["36_position_measured"]:
                    #     tag_set.pop('type')

                    print("Tags:",tag_set)
                    response = messaging_kinect.node_red(tag_set)
                    # TODO: Remove when server is back up
                    # response = {"33_right_ready" : False, "35_payload_grasped" : False, "36_position_measured" : True}

                    print("Response:", response)
                    print("done sending to client")
                    print("response[33_right_ready]", response["33_right_ready"])
                    print("response[35_payload_grasped] not", response["35_payload_grasped"])
                    print("response[36_position_measured]", response["36_position_measured"])
                except:
                    print("Couldn't send data3")
                    try:
                        tag_set = Payload().tags()
                        tag_set['number_of_payloads'] = len(payloads)
                        print("Tags:",tag_set)
                        response = messaging_kinect.node_red(tag_set)
                    except:
                        print("Couldn't send data4")
                    continue

            break

    final_image = cv2.resize(final_image,(648,488))
    final_image = cv2.cvtColor(final_image, cv2.COLOR_BGR2RGB)
    # Push image to video server
    # flask.push(rgb_image)
    cv2.imshow(video_feed_name, final_image)
    kinect_utils.show_depth(depth_array, depth_feed_name)

    cv2.waitKey(1)
    #if (cv2.waitKey(1) & 0xFF) == 27:
    #    break

    frame_count += 1
    print("Frame count:", frame_count)

print("exited while loop")