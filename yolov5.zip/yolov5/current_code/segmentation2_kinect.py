import math
import time
from time import time as now
import cv2
import numpy as numpy
import numpy as np
from payload_kinect import Payload
# from Yolov5Model import Yolov5Model

# def main():
#     yolo_model = Yolov5Model()
#     template = cv2.imread('mtre4800-kawasaki-project/three_containers1.jpg')
#     template = cv2.resize(template, (640, 480))
#     payloads = getPayloads(template)
#     print("Payloads:", payloads)
#     rgb_image = cv2.imread('mtre4800-kawasaki-project/three_containers1.jpg')
#     rgb_image = cv2.resize(rgb_image, (640, 480))
#     print(yolo_model.getPrediction(yolo_model.model, rgb_image, payloads))

def perspective(img):
    # assumes 640X480 resolution
    input_pts = numpy.float32([[634,0],[636,482],[28,484],[9,27]])
    output_pts = numpy.float32([[0,0],[0,488],[648,488],[648,0]])
    M = cv2.getPerspectiveTransform(input_pts,output_pts)
    img = cv2.warpPerspective(img,M,(img.shape[1], img.shape[0]),flags=cv2.INTER_LINEAR)
    return img

def get_sample(payload, image, hsize=180):
    # Sample is here now to condense functions (getPayload())
    # image = cv2.resize(image[300:3500,300:3500],(640, 480))

    center = (payload.x, payload.y)
    center = adjust_sample_center(center, image.shape, hsize)
    pt1 = (center[0]-hsize, center[1]-hsize)
    pt2 = (center[0]+hsize, center[1]+hsize)
    sample = image[pt1[1]:pt2[1],pt1[0]:pt2[0]]
    return sample

# Get payloads and return payloads
def get_home_orientation(image):
    # Set workspace boundaries (Camera FoV) and
    # Resize the image
    x_crop, y_crop = 20, 90
    image = cv2.resize(image[x_crop:560,y_crop:560],(640,480))
    
    # Grayscale image
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Dilate image (Add white pixels to mask based on k_size)
    k_size = 1
    kernelmatrix = np.ones((k_size, k_size), np.uint8)
    dilated = cv2.dilate(gray, kernelmatrix)

    # Blur image
    blurry = cv2.GaussianBlur(dilated,(9,9), 2)

    # Mask image
    lower_mask, upper_mask = 110, 215
    mask = cv2.inRange(blurry, lower_mask, upper_mask)

    # Invert masked image
    lower_invert, upper_invert = 0, 255
    _, inv_image = cv2.threshold(mask, lower_invert, upper_invert, cv2.THRESH_BINARY_INV)

    # cv2.imshow('Mask/Inv', np.vstack([mask,inv_image]))
    # cv2.waitKey(2000)

    # Find the contours in the image
    contours, _ = cv2.findContours(inv_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    print("Number of Contours found = " + str(len(contours)))

    # copy = image.copy()
    # contours_image = cv2.drawContours(copy, contours, -1, (255,0,255), 2)
    refined_contours = []
    contour_area_list = []

    # Check area of contours to refine payload detection
    min_contour_area, max_contour_area = 4500, 26000
    for c in contours:
        contour_area = cv2.contourArea(c, False)
        if abs(contour_area >= min_contour_area) and abs(contour_area) <= max_contour_area:
            refined_contours.append(c)
            contour_area_list.append(contour_area)

    print("Number of Refined Contours found = " + str(len(refined_contours)))

    # targets_boxes = []
    # targets_bounds = []
    # for c in contours:
    #     x, y, w, h = cv2.boundingRect(c)
    #     box = (x, y, w, h)
    #     bounds = cv2.minAreaRect(c)
    #     targets_boxes.append(box)
    #     targets_bounds.append(bounds)

    # copy1 = image.copy()
    # new_contours_image = cv2.drawContours(copy1, refined_contours, -1, (255,0,0), 2)
    
    # cv2.imshow('Contours_image/New_contours_image', np.hstack([contours_image,new_contours_image]))
    # cv2.waitKey(2000)

    center = (0,0)
    selected = -1
    payloads = []
    orientation_bbox = []
    regular_bbox = []
    index = 0
    for contour in refined_contours:
        # Orientation bbox
        # Contours -> Rotated rectangular boundaries
        bounds = cv2.minAreaRect(contour)
        # Rotated rectangular boundaries -> Oriented Bbox
        oriented_bbox = cv2.boxPoints(bounds)
        # Box corners -> int
        oriented_bbox = numpy.int0(oriented_bbox)
        orientation_bbox.append(oriented_bbox)

        # Regular bbox
        # Center_x, center_y, width, height
        x, y, w, h = cv2.boundingRect(contour)
        regular_bbox = (x, y, w, h)
        regular_bbox.append(regular_bbox)

        # Calculate the closest orientated bbox
        # Subtract old center x from width/2
        oc_dx = abs(center[0]-(image.shape[1]/2))
        # Subtract old center y height/2
        oc_dy = abs(center[1]-(image.shape[0]/2))
        # Calculate old distance
        old_distance = math.sqrt(oc_dx**2+oc_dy**2)

        # Center of orientated bbox
        new_center = numpy.int0(bounds[0])
        # Subtract new center x from width/2
        nc_dx = abs(new_center[0]-(image.shape[1]/2))
        # Subtract new center y height/2
        nc_dy = abs(new_center[1]-(image.shape[0]/2))
        # Calculate new distance
        new_distance = math.sqrt(nc_dx**2+nc_dy**2)

        # Add new payload to payload list
        new_payload = Payload()
        new_payload.bounds = bounds
        new_payload.boxes = regular_bbox
        
        # TODO: Test and adjust these ratios
        # Pixel to mm ratio (pixels/mm)
        x_ratio, y_ratio, c_ratio = 4.068, 4.966, 4.52
        new_payload.x = int((new_center[0]*y_ratio)+y_crop)   # Right y boundary
        new_payload.y = int((new_center[1]*x_ratio)+x_crop)   # Left x boundary
        new_payload.r = reference_rotation(bounds, new_payload.type)
        new_payload.distance = new_distance*c_ratio         # Distance from center (Avg of x and y ratios)
        payloads.append(new_payload)

        # Compare payload distances and select closest
        if new_distance < old_distance:
            selected = index
            center = new_center
        index += 1
    
    if len(payloads) > 0:
        payloads[selected].selected = 1
    return payloads, orientation_bbox, regular_bbox

# FIXME: Work on this (Get bounding boxes then Draw the payloads on the image)
# Add getPayload and draw payloads to the test code at the bottom
# Returns bounding boxes and image sample
'''
def getBoundingBox(center, frame, hsize=180): #payload
    # center = (payload.x, payload.y)
    # FIXME: Ask Tim: Can you explain this?
    # center = adjust_sample_center(center, image.shape, hsize)
    pt1 = (center[0]-hsize, center[1]-hsize)
    pt2 = (center[0]+hsize, center[1]+hsize)
    sample = frame[pt1[1]:pt2[1],pt1[0]:pt2[0]]
    sample_template = frame[pt1[1]:pt2[1],pt1[0]:pt2[0]]

    [tR, tG, tB] = cv2.split(sample_template)
    [iR, iG, iB] = cv2.split(sample)

    dR = cv2.absdiff(iR, tR)
    dG = cv2.absdiff(iG, tG)
    dB = cv2.absdiff(iB, tB)
    bl = 19
    cn = 15
    tR = cv2.adaptiveThreshold(dR,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,bl,cn)
    tG = cv2.adaptiveThreshold(dG,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,bl,cn)
    tB = cv2.adaptiveThreshold(dB,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,bl,cn)
    # TODO: experiment with merging channels
    difference = cv2.merge([tR,tG,tB])
    #cv2.imshow('fuzzy', cv2.merge([dR,dG,dB]))
    difference = cv2.cvtColor(difference,cv2.COLOR_BGR2GRAY)
    
    k_size = 15
    kernelmatrix = np.ones((k_size, k_size), np.uint8)
    # TODO: Fix black boxes dilate add more white pixel around other white pixels based on k_size
    d = cv2.dilate(difference, kernelmatrix)
    
    fuzzy = cv2.GaussianBlur(d, (9,9), 4)
    
    contours, _ = cv2.findContours(fuzzy, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)

    targets = []
    for contour in contours:
        bounds = cv2.minAreaRect(contour)
        # if circle
            # bounds[2]
        # if check_size_hi(bounds):
        targets.append(bounds)
    
    if len(targets) > 0:
        # if len(targets) > 1:
        #     target = checkOverlap(targets)
        # else:
        #     target = targets[0]
    
        adjusted_center = (target[0][0] + pt1[0], target[0][1] + pt1[1])
        payload.x = int(adjusted_center[0])
        payload.y = int(adjusted_center[1])
        payload.r = reference_rotation(target, payload)
        target = (adjusted_center,target[1],target[2])
        box = cv2.boxPoints(target)
        box = np.int0(box)
        return box, sample
    else:
        return None, sample
'''

# FIXME: Ask Tim: What are these checking for?
# FIXME: Ask Tim: Why index 1 not 0?
# If the contours are too small or too big, ignore.
def check_size_hi(bounds):
# Reduce until the payload are excluded, then put back up
    width = bounds[1][0]
    height = bounds[1][1]
    area = width*height
    return ((area < 200000) and (area > 40000)) and ((width >200) and (height > 200)) and ((height < 500) and (width < 500))

def check_size_low(bounds):
    width = bounds[1][0]
    length = bounds[1][1]
    area = width*length


# Increase until the payload are excluded, then go back up
    side_upper_limit = 1000
    side_lower_limit = 10
    area_upper_limit = 600000
    area_lower_limit = 100
    areaOK = ( (area < area_upper_limit) and (area > area_lower_limit) )
    widthOK = ((width < side_upper_limit ) and (width > side_lower_limit) )
    lengthOK = ( (length < side_upper_limit) and (length > side_lower_limit) )
    return (areaOK and widthOK and lengthOK)

# Place caps measure in mm
# take a picture
# measure in pixel
# MS Paint
# Robot at home
# Robot at 4 ft off the ground
def convert_units(x,y,shape):
    # TODO: Re-measure center
    x = -( x - (shape[1]/2) - 73 )
    y = ( y - (shape[0]/2) + 11 )
    # mm_px = 1.49
    x_ratio, y_ratio, c_ratio = 4.068, 4.966, 4.52
    x *= y_ratio
    y *= x_ratio
    return x, y

# FIXME: Ask Tim: Can you please explain this?
# Limited by sensor cable
# Uses long side to pick refernce origin
# Adjust for bucket
# -bounds to make sure the axis line up
# cv cw -> +
# robot ccw -> +
def reference_rotation(bounds, payload):
    if payload.type != 1:
        adjust = 0
        width = bounds[1][0]
        height = bounds[1][1]
        if width < height:
            return (90 - bounds[2]) + adjust
        else:
            return (-bounds[2]) + adjust
    else:
        return adjust
    
        

def adjust_sample_center(center, shape, sample_size):
    if center[0] < sample_size:
        adjust = sample_size - center[0]
        center = (center[0]+adjust, center[1])
    elif center[0] > shape[1]-sample_size:
        adjust = sample_size - (shape[1]-center[0])
        center = (center[0]-adjust, center[1])

    if center[1] < sample_size:
        adjust = sample_size - center[1]
        center = (center[0],center[1]+adjust)

    elif center[1] > shape[0]-sample_size:
        adjust = sample_size-(shape[0]-center[1])
        center = (center[0],center[1]-adjust)

    return center

def checkOverlap(targets):
    # TODO: Test function
    area = 0
    selection = 0
    for index, payload in enumerate(targets):
        nwidth = payload[1][0]
        nlength = payload[1][1]
        narea = nwidth*nlength
        if narea > area:
            area = narea
            selection = index
    return targets[selection]

def draw_payloads(image, payloads, bounding_box, labels):
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    for index, payload in enumerate(payloads):
        print("draw payloads.selected:", payload.selected)
        center = (payload.x, payload.y)
        color = (0,0,255)
        # font_color = (0,0,0)
        # if payload.selected:
        if True:
            center = (payload.x, payload.y)
            color = (0,255,0)
            if bounding_box is not None:
                # cv2.drawContours(img, [bounding_box], 0, color, 2)
                cv2.drawContours(image, [bounding_box[index]], 0, (255, 255, 0), 2)
            print("center:", center)
        image = cv2.circle(image,center,4,color,3)
        # cv2.rectangle(img, (center[0]+7, center[1]-100), (center[0]+240, center[1]+80), (255,255,255), -1)
        # cv2.putText(img, "D: " + str(round(payload.distance,0))+'px', (center[0]+10, center[1]-60), cv2.FONT_HERSHEY_SIMPLEX, 1, font_color, 2)
        # cv2.putText(img, "X: " + str(round(payload.x,0)) + 'px', (center[0]+10, center[1]-30), cv2.FONT_HERSHEY_SIMPLEX, 1, font_color, 2)
        # cv2.putText(img, "Y: " + str(round(payload.y,0)) + 'px', (center[0]+10, center[1]), cv2.FONT_HERSHEY_SIMPLEX, 1, font_color, 2)
        # cv2.putText(img, "R: " + str(round(payload.r,0)) + 'deg', (center[0]+10, center[1]+30), cv2.FONT_HERSHEY_SIMPLEX, 1, font_color, 2)
        # cv2.putText(img, labels[payload.type], (center[0]+10, center[1]+60), cv2.FONT_HERSHEY_SIMPLEX, 1, font_color, 2)
        cv2.line(image, (int(image.shape[1]/2),int(image.shape[0]/2)), center, color, 1)
    cv2.imshow("Draw Payloads", image)
    cv2.waitKey(0)

# if __name__ == "__main__":
#     main()

# ADD Payload.selected here
# def main(self):
