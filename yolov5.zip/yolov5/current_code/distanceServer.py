# Test sending data to node-red
# Nia deployed to node red so the comms crashed 
# Must restart the Pi/PC

import messaging_kinect
#from messaging import send_distance
import socket
import json
#from time import time as now
#from copy import deepcopy

# class Tags:
#     def __init__(self):
#         self.vision_tags = { 'x':0 }
#         self.robot_tags  = { 'x':0 }
#         self.scada_tags  = { 'x':0 }
#         self.lag = { 'vision':now(), 'robot':now(), 'scada':now() }
    
#     def tags(self):
#         return deepcopy( self.__dict__ )

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        # s.bind(('', 5965)) # set to 6001 and in node-red
        s.bind(('', 6001))
        print("Bound to port")
        s.listen()          # Listen for info
        print("Listen")
        conn,addr = s.accept()  # opens the connect nodered to Python
        print("Accepted")
        with conn:
            while True:
                # data = conn.recv(1500)        # Used data need to be recieved
                # data = data.decode()
                tag_set = { 'testing': 0}
                print("Just set tag_set")
                middleman = messaging_kinect.client_send('node', tag_set, True)
                "Just set middleman with client_send()"
                # distance = middleman['node']['z1']
                # print(distance)
                # if not data:
                #     break

                s.sendall(json.dumps(middleman['vision_tags']))
        # tags = Tags()
        # tag_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # tag_server.bind(('', 5961))
        # tag_server.listen()
        # while True:
        #     connection, _ = tag_server.accept()
        #     with connection:
        #         try:
        #             message = messaging.recv_msg(connection)
        #         except:
        #             continue

        #         if message[0] == 'vision':
        #             tags.vision_tags = message[1]
        #         elif message[0] == 'robot':
        #             tags.robot_tags = message[1]
        #         elif message[0] == 'scada':
        #             tags.scada_tags = message[1]

        #         tags.lag[message[0]] = now()
        #         messaging.send_message(tags.tags(), connection)

if __name__ == '__main__':
    main()
            #         break