import cv2
# from AImodel import AIModel
from Yolov5Model import Yolov5Model
# import cameraInterface
from payload_kinect import Payload
import segmentation2_kinect as segmentation
# from segmentation2_kinect import (getPayload, getPayloads)
from time import time as now
from time import sleep
import messaging_kinect
import numpy as np
import videoServer_kinect as flask
import threading
import multiprocessing
import math
from copy import deepcopy
from math import sqrt

import torch
import torch.nn as nn
import freenect

'''
x = numpy.zeros((3,15,20))
x1 = numpy.reshape(x[0], (1,300))
x2 = numpy.reshape(x[1], (1,300))
x3 = numpy.reshape(x[2], (1,300))
y = numpy.concatenate((x1, x2, x3), 1)
print(x.shape, y.shape)
exit()
'''

# def select_device(device='', batch_size=0, newline=True):
#     # device = 'cpu' or '0' or '0,1,2,3'
#     s = f'YOLOv5 🚀 {git_describe() or file_update_date()} torch {torch.__version__} '  # string
#     device = str(device).strip().lower().replace('cuda:', '')  # to string, 'cuda:0' to '0'
#     cpu = device == 'cpu'
#     if cpu:
#         os.environ['CUDA_VISIBLE_DEVICES'] = '-1'  # force torch.cuda.is_available() = False
#     elif device:  # non-cpu device requested
#         os.environ['CUDA_VISIBLE_DEVICES'] = device  # set environment variable - must be before assert is_available()
#         assert torch.cuda.is_available() and torch.cuda.device_count() >= len(device.replace(',', '')), \
#             f"Invalid CUDA '--device {device}' requested, use '--device cpu' or pass valid CUDA device(s)"

#     cuda = not cpu and torch.cuda.is_available()
#     if cuda:
#         devices = device.split(',') if device else '0'  # range(torch.cuda.device_count())  # i.e. 0,1,6,7
#         n = len(devices)  # device count
#         if n > 1 and batch_size > 0:  # check batch_size is divisible by device_count
#             assert batch_size % n == 0, f'batch-size {batch_size} not multiple of GPU count {n}'
#         space = ' ' * (len(s) + 1)
#         for i, d in enumerate(devices):
#             p = torch.cuda.get_device_properties(i)
#             s += f"{'' if i == 0 else space}CUDA:{d} ({p.name}, {p.total_memory / (1 << 20):.0f}MiB)\n"  # bytes to MB
#     else:
#         s += 'CPU\n'

#     if not newline:
#         s = s.rstrip()
#     # LOGGER.info(s.encode().decode('ascii', 'ignore') if system() == 'Windows' else s)  # emoji-safe
#     LOGGER.info(s.encode().decode('ascii', 'ignore')) # if system() == 'Windows' else s)  # emoji-safe
#     return torch.device('cuda:0' if cuda else 'cpu')

# Start the video server
# TODO: Uncomment
# threading.Thread(target=lambda: flask.main()).start()

# Get predictions from class
#model = AIModel((1296,976), 440)
# model = AIModel()
# TODO: Make a function that returns predictions
yolo_model = Yolov5Model()

weights = 'mtre4800-kawasaki-project/best.pt'
device = torch.device('cpu') # TODO: Use the select_device()
# device = torch.device('cuda:0')

# Load the ML model
# model = torch.hub.load('ultralytics/yolov5', 'custom', path='mtre4800-kawasaki-project/best.pt')  # local model
# model = DetectMultiBackend(weights, device=device)

# TODO: Set the heights from the Kinect distance program here
# TODO: Add the bucket height
# FIXME Ask Tim: Which is which? ['black', 'amazon', 'clear', 'styro', 'null']?
# Order of heights are based on the training/labelling order
# From 24 in. from the ground (tallest container can be 24 in. in the future with this method)
heights = [-254, -374, -343, -275, 0]
# heights = [-254, -275, bucket, 0]

# template = cv2.imread('mtre4800-kawasaki-project/three_containers1.jpg')
# template = cv2.resize(template,(648,488))
# template = template[60:480,70:610]
# template = cv2.resize(template, (160,120))

scada = {'robot_tags':{'home':True}}
prediction = 3 #4

### Initialize Camera here
### initialize_kinect()

frame, _ = freenect.sync_get_video()

# frame = 0
# for frame in range(0, 100):
while frame is True:
    # Get the RGB image from the Kinect
    # TODO: Uncomment for live Kinect video feed
    rgb_image, _ = freenect.sync_get_video()

    cv2.rotate(rgb_image,cv2.ROTATE_180)
    # rgb_image = cv2.imread('mtre4800-kawasaki-project/three_containers4.jpg')
    rgb_image = cv2.resize(rgb_image, (640, 480))

    # TODO: Test this
    # Change test frame from RGB to BGR
    bgr_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)
    # frame += 1

    start = now()

    # Get payloads and bbox
    payloads, orientation_bounding_box, regular_bounding_box = segmentation.get_home_orientation(rgb_image)

    print("Number of payloads:", len(payloads))
    
    # bounding_box = None
    x = 0
    y = 0
    selected = 0
    for index, payload in enumerate(payloads):
        # FIXME: 2 AsK Tim: How does payload.selected work? Is it the box the gripper is going to pick up next?
        #                   Maybe remove since payloads are already checked
        if payload.selected:
        # if True:
            selected = index
            # bounding_box, sample = segmentation.getPayload(payload, rgb_image)
            sample = segmentation.get_sample(payload, rgb_image)
            if scada['robot_tags']['home']:
                # Get the closest prediction
                prediction = yolo_model.getPrediction(yolo_model.model, rgb_image, payload, selected)
                # prediction = model.getPrediction(sample, payload)
                payload.z = heights[payload.type]
            else:
                # Not at home, so no prediction
                payload.type = prediction
                payload.z = heights[payload.type]
            x, y = segmentation.convert_units(payload.x, payload.y, rgb_image.shape)

    if scada['robot_tags']['home']:
        segmentation.draw_payloads(rgb_image, payloads, bounding_box, yolo_model.labels)

    tag_set = Payload().tags()
    if len(payloads) > 0:
        # FIXME: 2 Ask Tim: Why are these not in a for loop?
        payloads[selected].x = x
        payloads[selected].y = y
        cv2.putText(rgb_image, "X: " + str(round(payloads[selected].x,0)) + 'mm', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        cv2.putText(rgb_image, "Y: " + str(round(payloads[selected].y,0)) + 'mm', (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)

        tag_set = deepcopy(payloads[selected].tags())

    tag_set['number_of_payloads'] = len(payloads)

    scada = messaging_kinect.client_send('vision', tag_set, True)
    #print(scada['scada_tags'])

    # Push image to video server
    img = cv2.resize(img,(648,488))
    flask.push(img)
    cv2.imshow("final", img)
    #if (cv2.waitKey(1) & 0xFF) == 27:
    #    break

    #cycle = (1/30)-(now()-start)
    #if cycle > 0.001:
    #    sleep(cycle)

    #print(round(now()-start,3)*1000, 'mS')
#cam.shutdown()
