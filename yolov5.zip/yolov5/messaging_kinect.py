import socket
import pickle
import struct
import json
from time import sleep

'''
def send_message(message, socket):
    data = pickle.dumps(message)
    data = struct.pack('>I', len(data)) + data
    socket.sendall(data)

def recv_msg(socket):
    # Read message length and unpack it into an integer
    packet = socket.recv(4)
    length = struct.unpack('>I', packet)[0]
    # Read the message data
    data = bytearray()
    while len(data) < length:
        packet = socket.recv(length - len(data))
        if not packet:
            return None
        data.extend(packet)
    message = pickle.loads(data)
    return message

def client_send(client, message, recieve=False):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as local:
            #local.settimeout(0.01)
            local.connect(('localhost', 8092)) # Must match port in server_kinect
            send_message((client, message), local)
            if recieve:
                return recv_msg(local)
    except:
        print("comms error")
        if recieve:
            return None
'''

def node_red(data):
    print("Node_red function")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as local:
            print("start test")
            f = "failed to connect"
            local.connect(('192.168.0.96', 9090)) # Must match port in node red
            print("connect")
            f = "failed to send"
            local.sendall(json.dumps(data).encode('utf-8'))
            print("send")
            f = "failed to recieve"
            response = json.loads(local.recv(4096).decode('utf-8'))
            print("recieved\ntestsuccesful")
            # sleep(1)
            return response
    except:
        print("comms error:",f)
        return None