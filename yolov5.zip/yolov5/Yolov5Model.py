###################################
#                                 #
# Must be in the yolov5 directory #
#                                 #
###################################

import freenect
import cv2
import numpy as np
import time
import math
import torch
import hubconf

class Yolov5Model:

    def __init__(self):
        # Load the model
        # Local
        self.model = hubconf.custom('mtre4800-kawasaki-project/best.pt')

        # From the Internet
        # self.model = torch.hub.load('ultralytics/yolov5', 'custom', path='mtre4800-kawasaki-project/best.pt')  # local model

        # Set custom inference settings
        self.model.agnostic = False            # NMS class-agnostic - Model uses the foreground to create bounding boxes instead of classes (pre-processor)
        # self.model.amp = False               # Automatic Mixed Precision (AMP) inference - If True, Applicable calculations are computed in 16-bit precision instead of 32-bit precision
        self.model.amp = True                  # Speeds up inference process
        self.model.classes = None              # (optional list) Filter by class, i.e. = [0, 15, 16] for COCO persons, cats and dogs
        self.model.conf = 0.60                 # NMS confidence threshold - Confidence value that the bounding box contains an object (Max = 1)
        self.model.dmb = True                  # 
        self.model.dump_patches = False        # 
        self.model.iou = 0.45                  # NMS IoU threshold - Bounding box overlap threshold
        self.model.max_det = 6                 # Maximum number of detections per image
        self.model.multi_label = False         # NMS multiple labels per box
        self.model.names = ['black_box', 'orange_bucket', 'styrofoam_box', 'null']         # Names of containers
        self.model.pt = True                   # Use ML model weights that are the .pt format
        self.model.stride = 32                 # 
        self.model.training = True             # 

        # self.labels = ['black', 'amazon', 'clear', 'styro', 'null']
        # self.labels = ['black_box', 'orange_bucket', 'styrofoam_box', 'null']

    # def getPrediction(self, model, image, payload):
    # def getPrediction(self, model, image, payload, selected):
    def getPrediction(self, model, payload):
        # sample = Image.fromarray(image).convert('L').resize(self.size, Image.ANTIALIAS)

        # image = cv2.resize(image[300:3500,300:3500],(640, 480))
        image = cv2.resize(image, (640, 480))
        
        # TODO: Test this
        # image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        x_shape, y_shape = image.shape[1], image.shape[0]

        # Set start time for FPS calculations
        start_time = time.time()

        # Choose custom inference size and save test results
        results = model(image, size=224) # 224, 416, 480, 360, 160, 640

        # Save the array of labels and the bounding box coordinates
        predicted_labels = results.xyxyn[0][:, -1].numpy()
        cord_thres = results.xyxyn[0][:, :-1].numpy()

        print("predicted_labels:", predicted_labels)
        print("Bounding Boxes Coordinates:\n", cord_thres)

        # Display the results in the terminal
        print("\nConcise Inference Results:")
        results.print()

        # print("\nCustom Inference Results:")

        # Calculate the FPS
        fps = '{:.1f}'.format(1 / (time.time() - start_time))

        # Display FPS 
        color = (255, 0, 0) # BGR
        cv2.putText(image, f'FPS: {fps}', (0, 15), font, font_scale, color, thickness)
        print(f'FPS: {fps}')

        # closest_prediction = 3
        center = (0,0)
        selected = -1
        if len(predicted_labels) != 0:
            # Convert predicted class labels (numeric) to readable labels
            for index in range(len(predicted_labels)):
                row = cord_thres[index]
                confidence = row[4]
                # If the confidence is > 0.6, predict_labels
                if confidence >= 0.6:
                    # Info to draw regular bounding box
                    # Uses coord_thres ratios to get bounding box coordinates
                    x1, x2, y1, y2 = int(row[0]*x_shape), int(row[2]*x_shape), int(row[1]*y_shape), int(row[3]*y_shape)
                    new_center = (int((x1+x2)/2), int((y1+y2)/2))

                    # Calculate closest payload
                    # Subtract old center x from width/2
                    oc_dx = abs(center[0]-(x_shape/2))
                    # Subtract old center y height/2
                    oc_dy = abs(center[1]-(y_shape/2))
                    # Calculate old distance
                    old_distance = math.sqrt(oc_dx**2+oc_dy**2)
                
                    new_center = np.int0(new_center)
                    # Subtract new center x from width/2
                    nc_dx = abs(new_center[0]-(x_shape/2))
                    # Subtract new center y height/2
                    nc_dy = abs(new_center[1]-(y_shape/2))
                    # Calculate new distance
                    new_distance = math.sqrt(nc_dx**2+nc_dy**2)

                    if predicted_labels[index] == 0:
                        color = (255, 0, 0) # BGR
                        label = "Black Box"
                        print(f"Black, plastic box was found! {new_distance}\n")
                    elif predicted_labels[index] == 1:
                        color = (0, 255, 0)
                        label = "Orange Bucket"
                        print(f"Orange, plastic bucket was found! {new_distance}\n")
                    elif predicted_labels[index] == 2:
                        color = (0, 0, 255)
                        label = "White Box"
                        print(f"White, Styrofoam box was found! {new_distance}\n")
                    else:
                        print("An error occurred!\n")

                    # Set drawing variables
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    font_scale = 0.5
                    thickness = 2

                    # Draw stuff on image
                    cv2.circle(image, new_center, 3, color, -1)
                    cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
                    cv2.putText(image, "{}: {} [{:.2f}]".format(predicted_labels[index], label, float(confidence)), (x1, y1-5), font, font_scale, color, thickness)
                    cv2.putText(image, str(round(new_center[0], 2)), (new_center[0],  new_center[1] - 20), font, font_scale, color, thickness)
                    cv2.putText(image, str(round(new_center[1], 2)), (new_center[0] , new_center[1]), font, font_scale, color, thickness)
                    cv2.putText(image, str(round(new_distance, 2)), (new_center[0], new_center[1] + 20), font, font_scale, color, thickness)
                    cv2.line(image, (int(x_shape/2), int(y_shape/2)), new_center, color, thickness-1)

                    # payload.type = int(predicted_labels[i])

                    if new_distance < old_distance:
                        selected = index
                        # closest_prediction = int(predicted_labels[i])
                        center = new_center

            # Set the payload type to the closest prediction                    
            payload.type = int(predicted_labels[selected])
            print("payload.type", payload.type)
            # payload.type = closest_prediction

            # return predicted_labels[selected]
            return predicted_labels, payload.type, image
        else:
            # Floor
            cv2.putText(image, "No containers were found.", (int(x_shape/2), int(y_shape/2)), font, font_scale, color, thickness)
            # print("No containers were found.\n")
            return predicted_labels, 3, image

# Function for testing
'''
def main():
    yolo_model = Yolov5Model()
    rgb_window_name = "RGB Video Feed"

    cv2.namedWindow(rgb_window_name, cv2.WINDOW_NORMAL)

    while True:
        image, _ = freenect.sync_get_video()
        # image = cv2.imread('mtre4800-kawasaki-project/three_containers3.jpg')
        # image = np.uint16(image)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        cv2.resize(image, (640,480))
        payload = 1
        # selected = 1

        predictions, closest_prediction, image = yolo_model.getPrediction(yolo_model.model, image, payload)
        
        print("predictions:", predictions)
        print("closest_prediction:", closest_prediction)

        image = cv2.resize(image, (640,480))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        cv2.imshow(rgb_window_name, image)
        cv2.waitKey(1)
    # path = str(f'/home/user/code/mtre4800-kawasaki-project/ml_distances.jpg')
    # cv2.imwrite(path, image)

if __name__ == "__main__":
    main()
'''