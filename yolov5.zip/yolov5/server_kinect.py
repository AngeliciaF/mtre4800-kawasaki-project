import messaging_kinect
import socket
from time import time as now
from copy import deepcopy

# Always start for sending node-red data from distanceServer.py
# This server is the PC
class Tags:
    def __init__(self):
        self.vision_tags = {'x': 0}
        self.robot_tags  = {'x': 0}
        self.scada_tags  = {'x': 0}
        self.node        = {'x': 0}
        self.lag         = {'vision': now(), 'robot': now(), 'scada': now(), 'node': now()}
    
    def tags(self):
        return deepcopy(self.__dict__)

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as tag_server:
        tags = Tags()
        tag_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # FIXME: 3 Ask Tim: Should we change this port since the other team is using it?
        tag_server.bind(('', 8091)) # Must match port in messaging_kinect
        tag_server.listen()
        print("Listening")
        while True:
            connection, _ = tag_server.accept()
            print("Accepted: Internal Server")
            with connection:
                try:
                    message = messaging_kinect.recv_msg(connection)
                except:
                    continue

                if message[0] == 'vision':
                    tags.vision_tags = message[1]
                elif message[0] == 'robot':
                    tags.robot_tags = message[1]
                elif message[0] == 'scada':
                    tags.scada_tags = message[1]
                elif message[0] == 'node':
                    tags.node = message[1]

                tags.lag[message[0]] = now()
                messaging_kinect.send_message(tags.tags(), connection)

if __name__ == '__main__':
    main()