from copy import deepcopy

class Payload():
    def __init__(self):
        self.left_robot_x = 0
        self.left_robot_y = 0
        self.left_robot_z = 0
        self.left_robot_r = 0
        self.type = 3   # Floor
        self.distance = 100001
        self.height = 0
        self.bounds = None
        self.boxes = None
        self.confidence = 0
        self.selected = 0

    def tags(self):
        tag_set = deepcopy(self.__dict__)
        tag_set.pop('bounds')
        tag_set.pop('boxes')
        tag_set.pop('selected')
        return tag_set
