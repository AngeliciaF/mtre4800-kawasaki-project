import math
from time import sleep
#from this import d
import numpy as np
import cv2
import freenect

#KINECT VISION VARIABLES - TUNING
xmin = 200 #default image/data threshold
xmax = 420
ymin = 120
ymax = 380

minrange = 500 #Buffer threshholds
maxrange = 5000

minheight = 300 #payload height safety values
maxheight = 420

robot_height = 1350 #Robot controller z value 1350mm
kinect_height = 1289 #distance from kinect to ground at measuring positon
end_effector_height = kinect_height - 120
kinect_offset = robot_height - kinect_height

samplesize = 50

#Helper functions, useful??
def get_video():
    rgb_image = freenect.sync_get_video(format=freenect.VIDEO_RGB)[0]
    return rgb_image

def get_depth():
    depth_array = freenect.sync_get_depth(format=freenect.DEPTH_REGISTERED)[0]
    return depth_array

def initialize_kinect():
    ctx = freenect.init()
    dev = freenect.open_device(ctx, freenect.num_devices(ctx) - 1)
    freenect.set_tilt_degs(dev, 0)
    freenect.close_device(dev)

def show_depth(image):
    image = image.astype(np.uint8)
    image = cv2.resize(image, (640,480), interpolation= cv2.INTER_AREA)
    image = np.dstack([image]*3)
    cv2.imshow("Depth Image",image)
    # cv2.waitKey(1)

def type_to_offset(type):#Determines the grabbing position based on which object is detected
    case = {
        0:40, #Black box, 3mm offset
        1:30, #Orange bucket, 4mm offset
        2:30, #White box, 7mm offset
        3:0  #Ground condition
    }
    return case.get(type)

def get_dist(depth_array, payload,payload_type,payload_boxes):

    offset = type_to_offset(payload_type)

    xmin = payload_boxes[0]
    xmax = payload_boxes[1]
    ymin = payload_boxes[2]
    ymax = payload_boxes[3]

    print("image bounds of selected box:",xmin,xmax,ymin,ymax)

    is_bad_guess = True
    i=0

    while is_bad_guess:

        # depth_array = get_depth()

        if depth_array is None:
            print("NO DEPTH IMAGE")
            return 0,0
        
        # show_depth(depth_array)
        # cv2.imshow("Depth Image",gdepth)
        # cv2.waitKey(0)

        gdepth = depth_array[ymin:ymax, xmin:xmax] #new array truncates to the target area

        gdepth = gdepth[gdepth < maxrange] #truncates again removing points outside buffer
        gdepth = gdepth[gdepth > minrange]

        # if gdepth is None:
        #     print("NO OBJECT IN BOUNDS")
        #     return 0,0

        gdepth_mins = np.partition(gdepth,samplesize)[:samplesize] #sample 100 closest points
        try:
            dist = round(np.mean(gdepth_mins)) #avg closest points for approx distance
        except:
            print("NaN Values")
            z, height = 0, 0
            break

        height = kinect_height - dist #height given by difference of EEf hieght and distance
        
        z = dist - (kinect_height - end_effector_height) + offset

        # Makes z a negative int
        payload.left_robot_z = int(z*-1)
        payload.height = int(height)

        print("depth payload type:",payload_type,"offset:",offset)
        print("estimated height:",height) 

        if (minheight < height < maxheight):
            is_bad_guess = False
        elif (i == 10):
            print("Payload is too short, likely the ground")
            z = 0
            is_bad_guess = False

        i += 1

    return z, height


def get_dist_test():
    while True:
        is_bad_guess = True
        i=0

        while is_bad_guess:
            gdepth = get_depth()

            if gdepth is None:
                print("NO DEPTH IMAGE")
                return 0,0
            
            show_depth(gdepth)
            # cv2.imshow("Depth Image", gdepth)
            # cv2.waitKey(0)

            gdepth = gdepth[gdepth < maxrange] #truncates again removing points outside buffer
            gdepth = gdepth[gdepth > minrange]

            if gdepth is None:
                print("NO OBJECT IN BOUNDS")
                return 0,0

            gdepth_mins = np.partition(gdepth,samplesize)[:samplesize] #sample 100 closest points

            dist = round(np.mean(gdepth_mins)) #avg closest points for approx distance

            height = kinect_height - dist #height given by difference of EEf hieght and distance

            offset = 40

            z = dist - (kinect_height - end_effector_height) + offset
            
            print("estimated distance:",dist) 
            print("estimated height:",height)
            print("robot command", z)
            print("estimated robot height",1350-z)

            if (minheight < height < maxheight):
                is_bad_guess = False
            elif (i == 5):
                print("Payload is too short, likely the ground")
                z = 0
                is_bad_guess = False

            i += 1

        sleep(.08)

    return z, height
# Function for testing

def main():
    get_dist_test()
if __name__ == "__main__":
    main()