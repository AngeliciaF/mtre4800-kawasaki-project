import math
from time import sleep
#from this import d
import numpy as np
import cv2
import freenect

#KINECT VISION VARIABLES - TUNING
xmin = 200 #default image/data threshold
xmax = 420
ymin = 120
ymax = 380

minrange = 500 #Buffer threshholds
maxrange = 5000

robot_height = 1350 #Robot controller z value 1350mm
kinect_height = 1289 #distance from kinect to ground at measuring positon
EE_height = kinect_height - 120
kinect_offset = robot_height - kinect_height

samplesize = 50

#Helper functions, useful??
def get_video():
    rgb_image = freenect.sync_get_video(format=freenect.VIDEO_RGB)[0]
    return rgb_image

def get_depth():
    depth_array = freenect.sync_get_depth(format=freenect.DEPTH_REGISTERED)[0]
    return depth_array

def initialize_kinect():
    ctx = freenect.init()
    dev = freenect.open_device(ctx, freenect.num_devices(ctx) - 1)
    freenect.set_tilt_degs(dev, 0)
    freenect.close_device(dev)

def type_to_offset(type):#Determines the grabbing position based on which object is detected
    case = {
        0:40, #Black box, 3mm offset
        1:60, #Orange bucket, 4mm offset
        2:70, #White box, 7mm offset
        3:0  #Ground condition
    }
    return case.get(type)

def get_dist(payload):
    # x, y, w, h = cv2.boundingRect(contour)
    # payload.box = (x, y, w, h)
    x1, x2, y1, y2 = payload.boxes[0], payload.boxes[1], payload.boxes[0] + \
                  payload.boxes[2], payload.boxes[1] + payload.boxes[3]

    #payload.distance #??

    # box_center = (int((x1+y1)/2),int((x2+y2)/2))
    # cv2.rectangle(image, (x1, x2), (y1, y2), (0, 255, 0), 2)
    # print(x1,x2,y1,y2)
    if x1>x2: #assures bounds are low to high
        temp = x1
        x1 = x2
        x2 = temp
    if y1>y2:
        temp = y1
        y1 = y2
        y2 = temp
    xmin = payload.boxes[0]
    xmax = payload.boxes[1]
    ymin = payload.boxes[2]
    ymax = payload.boxes[3]

    print("image bounds of selected box:",xmin,xmax,ymin,ymax)

    depth_array = get_depth()

    if depth_array is None:
        print("NO DEPTH IMAGE")
        return 0,0
    
    gdepth = depth_array[ymin:ymax, xmin:xmax] #new array truncates to the target area

    gdepth = gdepth[gdepth < maxrange] #truncates again removing points outside buffer
    gdepth = gdepth[gdepth > minrange]

    if gdepth is None:
        print("NO OBJECT IN BOUNDS")
        return 0,0

    gdepth_mins = np.partition(gdepth,samplesize)[:samplesize] #sample 100 closest points

    dist = round(np.mean(gdepth_mins)) #avg closest points for approx distance

    height = EE_height - dist #height given by difference of EEf hieght and distance

    offset = type_to_offset(payload.type)
    
    z = dist + offset

    # Makes z a negative int
    payload.z = int(str("-" + str(z)))
    payload.height = int(height)

    print("depth payload type:",payload.type,"offset:",offset)
    print("estimated distance:",payload.z) 
    print("estimated height:",height) 

    return z, height


def get_dist_test():
    while True:
        gdepth = get_depth()

        if gdepth is None:
            print("NO DEPTH IMAGE")
            return 0,0
        
        gdepth = gdepth[gdepth < maxrange] #truncates again removing points outside buffer
        gdepth = gdepth[gdepth > minrange]

        if gdepth is None:
            print("NO OBJECT IN BOUNDS")
            return 0,0

        gdepth_mins = np.partition(gdepth,samplesize)[:samplesize] #sample 100 closest points

        dist = round(np.mean(gdepth_mins)) #avg closest points for approx distance

        height = kinect_height - dist #height given by difference of EEf hieght and distance

        offset = 40

        z = dist - (kinect_height - EE_height) + offset
        
        print("estimated distance:",dist) 
        print("estimated height:",height)
        print("robot command", z)
        print("estimated robot height",1350-z)

        sleep(1)

    return z, height
# Function for testing

def main():
    get_dist_test()
if __name__ == "__main__":
    main()